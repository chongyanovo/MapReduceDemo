package Mapper_join;

public class MyReduce {
}
