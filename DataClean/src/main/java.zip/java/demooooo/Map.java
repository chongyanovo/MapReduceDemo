package demooooo;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class Map extends Mapper<LongWritable, Text, DataBean, Text> {
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] line = value.toString().split("\t");
        DataBean dataBean = new DataBean();
        dataBean.setArea(line[0]);
        dataBean.setSex(line[2]);
        context.write(dataBean, new Text(line[3]));
    }
}
