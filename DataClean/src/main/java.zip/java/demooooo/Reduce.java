package demooooo;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class Reduce extends Reducer<DataBean, Text, DataBean, Text> {
    @Override
    protected void reduce(DataBean key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        int count = 0;
        for (Text i : values) {
            count++;
        }
        context.write(key, new Text("\t" + String.valueOf(count)));
    }
}
